<template>
  <div class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200 fade-in">
    <div class="flex items-center mb-4">
      <div class="p-2 bg-blue-100 rounded-lg mr-3">
        <svg class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      </div>
      <h3 class="text-lg font-semibold text-gray-900">Agenda</h3>
    </div>

    <div v-if="loading" class="space-y-3">
      <div v-for="i in 4" :key="i" class="flex items-center space-x-3">
        <div class="w-8 h-4 bg-gray-200 rounded card-loading"></div>
        <div class="flex-1 h-4 bg-gray-200 rounded card-loading"></div>
      </div>
    </div>

    <div v-else class="space-y-3">
      <div
        v-for="(item, index) in agenda.items"
        :key="index"
        class="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-150"
      >
        <span class="flex-shrink-0 w-6 h-6 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center text-sm font-medium">
          {{ index + 1 }}
        </span>
        <div class="flex-1">
          <p class="text-gray-800 font-medium">{{ item.title }}</p>
          <p class="text-sm text-gray-500">{{ item.duration }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  loading: {
    type: Boolean,
    default: false
  }
})

const agenda = ref({
  items: [
    { title: "Introduction and Setup", duration: "0:00 - 2:30" },
    { title: "Core Concepts Overview", duration: "2:30 - 8:15" },
    { title: "Practical Implementation", duration: "8:15 - 15:20" },
    { title: "Best Practices & Tips", duration: "15:20 - 20:45" },
    { title: "Q&A and Conclusion", duration: "20:45 - 25:00" }
  ]
})
</script>
