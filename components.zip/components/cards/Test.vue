<template>
  <div>
    Test hello!

    {{ agenda }}
  </div>
</template>

<script setup>
const agenda = ref({
  items: [
    { title: "Introduction and Setup", duration: "0:00 - 2:30" },
    { title: "Core Concepts Overview", duration: "2:30 - 8:15" },
    { title: "Practical Implementation", duration: "8:15 - 15:20" },
    { title: "Best Practices & Tips", duration: "15:20 - 20:45" },
    { title: "Q&A and Conclusion", duration: "20:45 - 25:00" }
  ]
})
</script>
