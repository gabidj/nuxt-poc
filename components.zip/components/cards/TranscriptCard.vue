<template>
  <div class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200 fade-in lg:col-span-3">
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center">
        <div class="p-2 bg-green-100 rounded-lg mr-3">
          <svg class="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h3 class="text-lg font-semibold text-gray-900">Full Transcript</h3>
      </div>
      <button
        v-if="!loading"
        class="text-sm text-primary-600 hover:text-primary-700 font-medium"
        @click="showFullTranscript = !showFullTranscript"
      >
        {{ showFullTranscript ? 'Show Less' : 'Show More' }}
      </button>
    </div>

    <div v-if="loading" class="space-y-3">
      <div v-for="i in 6" :key="i" class="h-4 bg-gray-200 rounded card-loading" :class="{ 'w-4/5': i % 3 === 0 }"/>
    </div>

    <div v-else class="space-y-4">
      <div class="max-h-64 overflow-y-auto" :class="{ 'max-h-none': showFullTranscript }">
        <div
          v-for="segment in transcript.segments"
          :key="segment.timestamp"
          class="border-l-2 border-gray-200 pl-4 mb-4 hover:border-primary-300 transition-colors duration-150"
        >
          <div class="flex items-center mb-2">
            <span class="text-sm font-medium text-primary-600 mr-2">{{ segment.timestamp }}</span>
            <span class="text-sm text-gray-500">{{ segment.speaker }}</span>
          </div>
          <p class="text-gray-700 leading-relaxed">{{ segment.text }}</p>
        </div>
      </div>
      <div class="text-sm text-gray-500 border-t pt-4">
        Total duration: {{ transcript.totalDuration }} | {{ transcript.wordCount }} words
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  loading: {
    type: Boolean,
    default: false
  }
})

const showFullTranscript = ref(false)

const transcript = ref({
  totalDuration: "25:30",
  wordCount: "3,247",
  segments: [
    {
      timestamp: "00:00",
      speaker: "Presenter",
      text: "Welcome to this comprehensive guide on modern web development practices. Today we'll be exploring the latest trends and techniques that are shaping the industry."
    },
    {
      timestamp: "00:45",
      speaker: "Presenter",
      text: "Let's start by understanding the fundamental principles of component-based architecture and how it revolutionizes the way we build user interfaces."
    },
    {
      timestamp: "02:30",
      speaker: "Presenter",
      text: "Component reusability is one of the key benefits we get from modern frameworks like Vue, React, and Angular. By breaking down our UI into smaller, manageable pieces, we can..."
    },
    {
      timestamp: "05:15",
      speaker: "Presenter",
      text: "Now let's dive into state management. Proper state management is crucial for building scalable applications that can handle complex data flows and user interactions."
    },
    {
      timestamp: "08:20",
      speaker: "Presenter",
      text: "Performance optimization should be a priority from day one. We'll look at techniques like code splitting, lazy loading, and how to measure and improve your application's performance."
    }
  ]
})
</script>
