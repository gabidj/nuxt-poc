<template>
  <div class="max-w-2xl mx-auto">
    <div
      class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary-400 transition-colors duration-200"
      :class="{ 'border-primary-400 bg-primary-50': isDragOver }"
      @drop="handleDrop"
      @dragover.prevent="isDragOver = true"
      @dragleave="isDragOver = false"
      @dragenter.prevent
    >
      <div v-if="!isProcessing">
        <svg class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4z" />
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4" />
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Upload your video</h3>
        <p class="text-gray-600 mb-4">Drag and drop your video file here, or click to select</p>
        <input
          ref="fileInput"
          type="file"
          accept="video/*"
          class="hidden"
          @change="handleFileSelect"
        >
        <button
          class="bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition-colors duration-200 font-medium"
          @click="$refs.fileInput.click()"
        >
          Choose Video File
        </button>
        <p class="text-sm text-gray-500 mt-2">Supports MP4, MOV, AVI, and more</p>
      </div>

      <div v-else class="space-y-4">
        <div class="animate-spin rounded-full h-12 w-12 border-4 border-primary-200 border-t-primary-600 mx-auto"/>
        <h3 class="text-lg font-medium text-gray-900">Processing Video...</h3>
        <p class="text-gray-600">Analyzing content and generating insights</p>
      </div>
    </div>
  </div>
</template>

<script setup>
const emit = defineEmits(['video-uploaded'])
const props = defineProps({
  isProcessing: {
    type: Boolean,
    default: false
  }
})

const isDragOver = ref(false)

const handleDrop = (event) => {
  event.preventDefault()
  isDragOver.value = false

  const files = event.dataTransfer.files
  if (files.length > 0) {
    handleVideoFile(files[0])
  }
}

const handleFileSelect = (event) => {
  const file = event.target.files[0]
  if (file) {
    handleVideoFile(file)
  }
}

const handleVideoFile = (file) => {
  if (file.type.startsWith('video/')) {
    emit('video-uploaded', file)
  } else {
    alert('Please select a valid video file.')
  }
}
</script>
